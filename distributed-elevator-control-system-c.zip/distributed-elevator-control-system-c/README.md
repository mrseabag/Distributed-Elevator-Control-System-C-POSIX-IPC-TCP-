# Distributed Elevator Control System (C, POSIX IPC & TCP)

## Overview
This project simulates a distributed elevator control system using low-level C programming, POSIX shared memory, and TCP networking.

It models realistic elevator behaviour including:
- car movement between floors
- external and internal call handling
- door state transitions
- safety system monitoring

## Architecture
The system is split into multiple interacting processes:

- **controller**: coordinates requests and dispatch logic
- **car**: simulates elevator state and movement
- **call**: sends external floor requests
- **internal**: simulates in-car button presses
- **safety**: monitors and updates safety status

Processes communicate using:
- POSIX shared memory
- pthread mutexes and condition variables
- TCP sockets

## Technologies
- C
- POSIX shared memory
- pthreads
- TCP/IP sockets
- Makefile-based build system

## Build and Run

```bash
make
./controller
./car
```

Run additional components in separate terminals as needed:
```bash
./call
./internal
./safety
```

## Project Structure
- `controller.c` - request coordination and dispatch logic
- `car.c` - elevator simulation
- `call.c` - external call interface
- `internal.c` - internal button interface
- `safety.c` - safety system simulation
- `floors.*` - floor parsing / comparison helpers
- `net.*` - network helpers
- `common.h` - shared structures and constants

## Learning Outcomes
- systems programming in C
- concurrent programming and synchronization
- inter-process communication
- network protocol handling
- modelling of real-time control systems

## Notes
This repository has been cleaned and packaged for portfolio use.
